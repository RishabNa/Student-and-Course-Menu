package Rishab_Project3;
/*Rishab Nayar
 * ITSS 3312.002*/
public interface Human {
    public void setFirstName(String fs);
    public void setLastName(String ls);
}
