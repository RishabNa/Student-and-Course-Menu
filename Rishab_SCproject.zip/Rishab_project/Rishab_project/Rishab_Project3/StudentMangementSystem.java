package Rishab_Project3;
/*Rishab Nayar
 * ITSS 3312.002*/

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.io.*;

//SMS calls on the student class and implements Human Interface
public class StudentMangementSystem {
    Student[] students;
    Scanner input;
    File file;


    // Rearranged the existing code in project 3 and refined it
    StudentMangementSystem(int size) {
        students = new Student[size];
        input = new Scanner(System.in);

        try {
            file = new File("StudentReport.txt");
            file.createNewFile();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        initSMS();
    }

    public void initSMS() {
        int userChoice = userInput();
        while (userChoice != 0) {
            switch (userChoice) {
            case 1:
                addNewStudent();
                break;
            case 2:
                deactivate();
                break;
            case 3:
                printAll();
                break;
            case 4:
                printStudentbyID();
                break;
            case 5:
                assignCampusJob();
                break;
            case 6:
                displayCampusjobStudents();
                break;
            }
            userChoice = userInput();
        }

        /* User choice to terminate */
        
    } // Chekcs student and sees if it is a student employee

    private void displayCampusjobStudents() {
        for (Student student : students) {
            if(student instanceof Studen_Employee)
            {
                Studen_Employee.print((Studen_Employee) student);
            }
        }
    }

    public static int userInput() {
        System.out.println("***Welcome to Student Management System***" + "\nPress ‘1’ to add a student"
                + "\nPress ‘2’ to deactivate a student" + "\nPress ‘3’ to display all students"
                + "\nPress ‘4’ to search for a student by ID" + "\nPress '5'to assign a Campus Job"
                + "\nPress '6' to display all students with a Campus Job\n" + "Press ‘0’ to exit the system\n");

        Scanner input = new Scanner(System.in);
        int action = input.nextInt();
        return action;
    }

    public void addNewStudent() {
        Student s = new Student();
        System.out.println("Enter first name: ");
        String temp = input.nextLine();
        s.setFirstName(temp);

        System.out.println("Enter last name: ");
        temp = input.nextLine();
        s.setLastName(temp);

        System.out.println("Enter Student year: ");
        temp = input.nextLine();
        s.setStudentYear(temp);

        Random r = new Random();
        int x = r.nextInt(99);
        s.setStudentID(x);
        System.out.println();
        System.out.println(s.getFirstName() + " " + s.getLastName() + " has been added as a " + s.getStudentYear()
                + " with ID: " + s.getStudentID());
        System.out.println();

        for (int i = 0; i < students.length; i++) {
            if (students[i] == null) {
                students[i] = s;
                break;
            }
        }

    }

    public void deactivate() {
        System.out.print("Enter student ID that you wish to deactivate: ");
        int id = input.nextInt();
        input.nextLine();

        for (int i = 0; i < students.length; i++) {
            Student current = students[i];
            if (current.getStudentID() == id) {
                students[i].setActive(false);
                System.out.println(
                        students[i].getFirstName() + " " + students[i].getLastName() + " has been deactivated");
                return;
            }

        }
        System.out.println("no student found with ID: " + id);
    }

    public void printAll() {
        FileWriter myWriter = null;
        try {
            myWriter = new FileWriter("StudentReport.txt");
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        for (int i = 0; i < students.length; i++) {
            if(students[i]==null)
            {
                return;
            }
            System.out.println(students[i].getFirstName() + " " + students[i].getLastName());
            System.out.println("ID: " + students[i].getStudentID());
            System.out.println("Level: " + students[i].getStudentYear());
            System.out.println("Status: " + students[i].getActive());
            System.out.println();
            try {
                
                myWriter.append(students[i].getFirstName() + " " + students[i].getLastName()+" ID: " + students[i].getStudentID()+" Level: " + students[i].getStudentYear()+" Status: " + students[i].getActive()+"\n");
               
                //System.out.println("Successfully wrote to the file.");
              } catch (IOException e) {
                //System.out.println("An error occurred.");
                e.printStackTrace();
              }
        }
        try {
            myWriter.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void printStudentbyID() {
        System.out.print("Enter student ID that you wish to search for: ");
        int id = input.nextInt();
        input.nextLine();

        for (int i = 0; i < students.length; i++) {
            Student current = students[i];
            if (current.getStudentID() == id) {
                System.out.println(students[i].getFirstName() + " " + students[i].getLastName());
                System.out.println("ID: " + students[i].getStudentID());
                System.out.println("Level: " + students[i].getStudentYear());
                System.out.println("Status: " + students[i].getActive());
                System.out.println();
                return;
            }
        }
        System.out.println("no student found with ID: " + id);
    }

    public void assignCampusJob() {
        System.out.print("Enter student ID: ");
        int id = input.nextInt();
        System.out.println();
        input.nextLine();
        System.out.print("Enter student job: ");
        String job = input.nextLine();
        System.out.print("Enter student job type: ");
        String type = input.nextLine();

        for (int i = 0; i < students.length; i++) {
            Student current = students[i];
            if (current!=null && current.getStudentID() == id) {
                students[i] = new Studen_Employee(current.firstName, current.lastName, current.studentYear, current.studentID, job, type);
            } /*Instead of it being a regular studnent, its a student employee now
            Student employee is a subclass of student and will have every single property that the student class has*/

        }
    }
}
