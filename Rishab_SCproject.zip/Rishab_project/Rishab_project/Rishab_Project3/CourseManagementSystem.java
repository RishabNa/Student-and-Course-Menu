package Rishab_Project3;
/*Rishab Nayar
* ITSS 3312.002*/
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Scanner;

public class CourseManagementSystem {
    Scanner input;
    File file;
    FileWriter mycoursesWriter, mycourseassignmentWriter;

    CourseManagementSystem() {
        input = new Scanner(System.in);

        try {
            file = new File("Courses.txt");
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
                file.delete();
                file.createNewFile();
            }


            file = new File("CourseAssignment.txt");
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
                file.delete();
                file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        initCMS();
    }

    public void initCMS() {
        int userChoice = userInput();
        while (userChoice != 0) {
            switch (userChoice) { // Switch statement
            case 1:
                addCourse();
                break;
            case 2:
                assignStudent();
                break;
            case 3:
                dispStudents();
                break;
            }
            userChoice = userInput();
        }

    }
    /*Reads all students in the course assignments and prints it out*/
    public void dispStudents() {
        Scanner reader;
        try {
            reader = new Scanner(new File("CourseAssignment.txt"));
            while (reader.hasNextLine()) {
                System.out.println(reader.nextLine());
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    /* Takes stduent and course ID*/
    public void assignStudent() {
        // Asks for user input and checks if it is already in the file
        System.out.print("Enter student ID: ");
        int studentid = input.nextInt();
        System.out.print("Enter course ID: ");
        int courseid = input.nextInt();

        
        /*Puts course ID into the file*/
        try {
            mycourseassignmentWriter = new FileWriter("CourseAssignment.txt", true);
            mycourseassignmentWriter.append("Student ID: " + studentid + " course ID:" + courseid + "\n");
            mycourseassignmentWriter.close();
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }

    public void addCourse() {

        System.out.print("Enter course ID: ");
        int id = input.nextInt();
        System.out.println("Enter course name: ");
        input = new Scanner(System.in);
        String name = input.nextLine();

        Scanner reader;
        try {
            String s = "ID:" + id + " name: " + name;
            reader = new Scanner(new File("Courses.txt"));
            while (reader.hasNextLine()) {
                if(reader.nextLine().equals(s))
                {
                    System.out.println("course already exists");
                    return;
                }
                
            }
            
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        /*If id doesnt exist in the course file, then it adds it onto a new line*/
        try {
            mycoursesWriter = new FileWriter("Courses.txt", true);
            mycoursesWriter.append("ID:" + id + " name: " + name + "\n");
            mycoursesWriter.close();

        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }
    /*method*/
    public static int userInput() {
        System.out.println("***Welcome to CMS***"
                + "\n\nPress ‘1’ to add a new course\nPress ‘2’ to assign student a new course\nPress ‘3’ to display student with assigned courses\nPress ‘0’ to exit CMS");

        Scanner input = new Scanner(System.in);
        int action = input.nextInt();
        return action;
    }
}
