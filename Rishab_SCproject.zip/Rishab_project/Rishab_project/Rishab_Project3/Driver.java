package Rishab_Project3;
/*Rishab Nayar
 * ITSS 3312.002*/
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class Driver {
    public static void main(String[] args) {
        System.out.println("Welcome to Student and Course Management System!");
        System.out.println("This system will allow you to manage students and courses.");
        System.out.print("Please enter the total number of students that you want into the system: ");
        // Take number of students
        Scanner input = new Scanner(System.in);
        int size = input.nextInt();
        System.out.println();
        input.nextLine();

        int system = 3;
        system = userInput();
        while (system != 0) {
            switch(system) // Switch statement to replace if statements
            {
                case 1:
                    StudentMangementSystem students = new StudentMangementSystem(size);
                    break;
                case 2:
                    CourseManagementSystem cms = new CourseManagementSystem();
                    break;
            }
            
            system = userInput();
        }

    }

    public static int userInput() {
        System.out.println("***Welcome to Student and Course Management System***"
                + "\n\nPress ‘1’for Student Management System (SMS)" + "\nPress ‘2’ for Course Management System (CMS)"
                + "\nPress ‘0’ to exit the system\n");

        Scanner input = new Scanner(System.in);
        int action = input.nextInt();
        return action;
    }

}

