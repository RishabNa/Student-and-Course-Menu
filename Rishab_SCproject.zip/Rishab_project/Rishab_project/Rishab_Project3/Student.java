package Rishab_Project3;
/*Rishab Nayar
 * ITSS 3312.002*/
public class Student implements Human {
    /* Variables */
    String firstName;
    String lastName;
    String studentYear;
    int studentID;
    boolean active;
    

    /* Constructor for the creation of new students */
    public Student() {
        firstName = "";
        lastName = "";
        String studentYear = "";
        int studentID = 0;
        active = true;
    }

    /* Sets acquired names */
    public void setFirstName(String fs) {
        firstName = fs;
    }
    public void setLastName(String ls) {
        lastName = ls;
    }
    public void setStudentYear(String sy) {
        studentYear = sy;
    }
    public void setStudentID(int i) {
        studentID = i;
    }
    public void setActive(boolean b) {
        active = false;
    }

    /* Gets acquired names */
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public String getStudentYear() {
        return studentYear;
    }
    public int getStudentID() {
        return studentID;
    }
    public boolean getActive() {
        return active;
    }
}