package Rishab_Project3;
/*Rishab Nayar
 * ITSS 3312.002*/
public interface Course {
    public void addCourse();
    public void assignStudent();
    public void dispStudents();
}
