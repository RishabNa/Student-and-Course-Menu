package Rishab_Project3;
/*Rishab Nayar
 * ITSS 3312.002*/
public class Studen_Employee extends Student {
    String type;
    String job;

    Studen_Employee(String firstName, String lastName, String studentYear, int studentID, String job, String type)
    {
        super();
        this.job = job;
        this.type = type;
        super.setFirstName(firstName);
        super.setLastName(lastName);
        super.setStudentYear(studentYear);
        super.setStudentID(studentID);
    }
    public static void print(Studen_Employee stutdent)
    {
        System.out.println("ID: " + stutdent.getStudentID()+" name: "+stutdent.getFirstName() + " " + stutdent.getLastName()+" type: "+stutdent.type+" job: "+stutdent.job);
    }
}
